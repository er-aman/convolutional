from cnn import CNN
import keras
from keras.datasets import mnist


class test_file_eval:

    batch = 128

    number_of_classes = 10
    epochs = 1

    input_dim_x, input_dim_y = 28, 28

    (x_train, y_train), (x_test, y_test) = mnist.load_data()

    x_train = x_train.reshape(x_train.shape[0], input_dim_x, input_dim_y, 1)
    x_test = x_test.reshape(x_test.shape[0], input_dim_x, input_dim_y, 1)
    shape_input = (input_dim_x, input_dim_y, 1)

    x_train = x_train.astype('float32')
    x_test = x_test.astype('float32')
    x_train /= 255
    x_test /= 255
    y_train = keras.utils.to_categorical(y_train, number_of_classes)
    y_test = keras.utils.to_categorical(y_test, number_of_classes)

    model = CNN()
    model.add_input_layer(shape_input)
    model.append_conv2d_layer(32, 5, padding='same', strides=1, activation='relu', name="", trainable=True)
    model.append_maxpooling2d_layer(pool_size=2, padding="same", strides=2, name="")
    model.append_conv2d_layer(64, 5, padding='same', strides=1, activation='relu', name="", trainable=True)
    model.append_maxpooling2d_layer(pool_size=2, padding="same", strides=2, name="")
    model.append_flatten_layer(name="")
    model.append_dense_layer(1000, activation="relu", name="", trainable=True)
    model.append_dense_layer(number_of_classes, activation="softmax", name="", trainable=True)
    model.set_loss_function(loss="categorical_crossentropy")
    model.set_optimizer(optimizer="SGD", learning_rate=0.01, momentum=0.0)
    model.set_metric(['accuracy'])
    model.train(x_train, y_train, batch, epochs)

    score = model.evaluate(x_test, y_test)
    print(score)